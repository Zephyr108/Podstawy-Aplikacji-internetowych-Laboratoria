function oblicz()
{
    document.getElementById("k").innerHTML="";
    document.getElementById("rm").value="";
    document.getElementById("kzo").value="";
    
    var kw=parseInt(document.getElementById("kw").value);
    var ir=parseInt(document.getElementById("ir").value);
    var pr=parseInt(document.getElementById("pr").value);

   
        var r=(kw*(pr/12))/(1-(1/(Math.pow((1+(pr/12)),ir))));

        var rm=document.getElementById("rm");
        var kzo=document.getElementById("kzo");

   
    if(isFinite(r) && !(isNaN(r)))
    {
        rm.value=r;
        kzo.value=r*ir;
    }
    else
    {
        document.getElementById("k").innerHTML="Podane wartości nie są skończonymi liczbami!";
    }



    
   
}