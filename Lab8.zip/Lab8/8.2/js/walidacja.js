function sprawdzPole(pole_id, obiektRegex) 
{
    var obiektPole = document.getElementById(pole_id);
    return obiektRegex.test(obiektPole.value);
}

function sprawdz_radio(nazwa_radio) 
{
    var obiekt = document.getElementsByName(nazwa_radio);
    for (var i = 0; i < obiekt.length; i++) 
    {
        if (obiekt[i].checked) 
        {
            return true;
        }
    }
    return false;
}

function sprawdz_box(box_id) 
{
    var obiekt = document.getElementById(box_id);
    return obiekt.checked;
}

function odczyt_radio(nazwa_radio) 
{
    var nr = document.getElementsByName(nazwa_radio);
    for (var i = 0; i < nr.length; i++) 
    {
        if (nr[i].checked) {
            return nr[i].value;
        }
    }
    return '';
}

function sprawdz() 
{   
    var ok = true; 

    var obiektNazw = /^[a-zA-Z]{2,20}$/;
    var obiektemail = /^([a-zA-Z0-9])+([.a-zA-Z0-9_-])*@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-]+)+$/;
    var obiektWiek = /^[1-9][0-9]{1,2}$/;
    
    if (!sprawdzPole("nazw", obiektNazw)) 
    { 
        ok = false;
        document.getElementById("nazw_error").innerHTML = "Wpisz poprawnie nazwisko!";
    } 
    else 
    {
        document.getElementById("nazw_error").innerHTML = "";
    }

    if (!sprawdzPole("wiek", obiektWiek)) 
    { 
        ok = false;
        document.getElementById("wiek_error").innerHTML = "Wpisz poprawnie wiek!";
    } 
    else 
    {
        document.getElementById("wiek_error").innerHTML = "";
    }

    if (!sprawdzPole("email", obiektemail)) 
    { 
        ok = false;
        document.getElementById("email_error").innerHTML = "Wpisz poprawnie email!";
    } 
    else 
    {
        document.getElementById("email_error").innerHTML = "";
    }

    if (!sprawdz_box("php") && !sprawdz_box("c") && !sprawdz_box("java")) 
    { 
        ok = false;
        document.getElementById("produkt_error").innerHTML = "Musisz wybrać produkt!";
    } 
    else 
    {
        document.getElementById("produkt_error").innerHTML = "";
    }

    if (!sprawdz_radio("zaplata")) 
    { 
        ok = false;
        document.getElementById("zaplata_error").innerHTML = "Musisz wskazać sposób płatności!";
    } 
    else 
    {
        document.getElementById("zaplata_error").innerHTML = "";
    }

    var dane = 'Dane z wypełnionego przez Ciebie formularza:\n';
    dane += 'Nazwisko: ' + document.getElementById("nazw").value + '\n';
    dane += 'Wiek: ' + document.getElementById("wiek").value + '\n';
    dane += 'Kraj: ' + document.getElementById("kraj").value + '\n';
    dane += 'Email: ' + document.getElementById("email").value + '\n';
    dane += 'Wybrane produkty: ' + (sprawdz_box("php") ? 'PHP ' : '') + (sprawdz_box("c") ? 'C ' : '') + (sprawdz_box("java") ? 'Java' : '') + '\n';
    dane += 'Sposób zapłaty: ' + odczyt_radio("zaplata");

    if(ok)
    {
        alert(dane);
    }
    

    return ok;
}

