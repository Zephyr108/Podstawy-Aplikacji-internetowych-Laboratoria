function oblicz() {
  var k = parseFloat(document.getElementById('kwota_pozyczki').value);
  var n = parseInt(document.getElementById('liczba_rat').value);
  var pr = parseFloat(document.getElementById('oprocentowanie_roczne').value);
  var pr_mc = pr / 12;
  var rata = (k*pr_mc)/(1-(1/(Math.pow((1 + pr_mc),n))));
  if(isNaN(rata)) {
    alert('Jest wpisana niepoprawna wartość!!!');
  }
  else {
    document.getElementById('oprocentowanie_miesieczne').value = pr_mc.toFixed(3);
    document.getElementById('odsetki').value = rata.toFixed(3);
  }
}
